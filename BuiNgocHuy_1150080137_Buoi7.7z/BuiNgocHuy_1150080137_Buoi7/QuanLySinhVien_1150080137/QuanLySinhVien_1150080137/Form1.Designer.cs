﻿namespace QuanLySinhVien_1150080137
{
	partial class Form1
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null)) components.Dispose();
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		private void InitializeComponent()
		{
			this.lblMaSV = new System.Windows.Forms.Label();
			this.lblTenSV = new System.Windows.Forms.Label();
			this.lblGioiTinh = new System.Windows.Forms.Label();
			this.lblNgaySinh = new System.Windows.Forms.Label();
			this.lblQueQuan = new System.Windows.Forms.Label();
			this.lblMaLop = new System.Windows.Forms.Label();
			this.txtMaSV = new System.Windows.Forms.TextBox();
			this.txtTenSV = new System.Windows.Forms.TextBox();
			this.cbGioiTinh = new System.Windows.Forms.ComboBox();
			this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
			this.txtQueQuan = new System.Windows.Forms.TextBox();
			this.cbMaLop = new System.Windows.Forms.ComboBox();
			this.btnThemNo = new System.Windows.Forms.Button();
			this.btnThemPara = new System.Windows.Forms.Button();
			this.btnSuaNo = new System.Windows.Forms.Button();
			this.btnSuaPara = new System.Windows.Forms.Button();
			this.btnXoaNo = new System.Windows.Forms.Button();
			this.btnXoaPara = new System.Windows.Forms.Button();
			this.lsv = new System.Windows.Forms.ListView();
			this.colMaSV = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.colTenSV = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.colGioiTinh = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.colNgaySinh = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.colQueQuan = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.colMaLop = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.cbFilterLop = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.grpLop = new System.Windows.Forms.GroupBox();
			this.btnThemLop = new System.Windows.Forms.Button();
			this.txtTenLopNew = new System.Windows.Forms.TextBox();
			this.txtMaLopNew = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.groupBox1.SuspendLayout();
			this.grpLop.SuspendLayout();
			this.SuspendLayout();
			// labels & inputs
			this.lblMaSV.AutoSize = true; this.lblMaSV.Location = new System.Drawing.Point(18, 28);
			this.lblMaSV.Text = "Mã SV:";
			this.lblTenSV.AutoSize = true; this.lblTenSV.Location = new System.Drawing.Point(18, 60);
			this.lblTenSV.Text = "Tên SV:";
			this.lblGioiTinh.AutoSize = true; this.lblGioiTinh.Location = new System.Drawing.Point(18, 92);
			this.lblGioiTinh.Text = "Giới tính:";
			this.lblNgaySinh.AutoSize = true; this.lblNgaySinh.Location = new System.Drawing.Point(18, 124);
			this.lblNgaySinh.Text = "Ngày sinh:";
			this.lblQueQuan.AutoSize = true; this.lblQueQuan.Location = new System.Drawing.Point(18, 156);
			this.lblQueQuan.Text = "Quê quán:";
			this.lblMaLop.AutoSize = true; this.lblMaLop.Location = new System.Drawing.Point(18, 188);
			this.lblMaLop.Text = "Mã lớp:";

			this.txtMaSV.Location = new System.Drawing.Point(95, 25); this.txtMaSV.Size = new System.Drawing.Size(220, 20);
			this.txtTenSV.Location = new System.Drawing.Point(95, 57); this.txtTenSV.Size = new System.Drawing.Size(220, 20);
			this.cbGioiTinh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbGioiTinh.Location = new System.Drawing.Point(95, 89); this.cbGioiTinh.Size = new System.Drawing.Size(120, 21);
			this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dtpNgaySinh.Location = new System.Drawing.Point(95, 121); this.dtpNgaySinh.Size = new System.Drawing.Size(120, 20);
			this.txtQueQuan.Location = new System.Drawing.Point(95, 153); this.txtQueQuan.Size = new System.Drawing.Size(220, 20);
			this.cbMaLop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbMaLop.Location = new System.Drawing.Point(95, 185); this.cbMaLop.Size = new System.Drawing.Size(220, 21);

			// buttons CRUD (No/Param)
			this.btnThemNo.Location = new System.Drawing.Point(21, 222); this.btnThemNo.Size = new System.Drawing.Size(95, 28);
			this.btnThemNo.Text = "Thêm (No)"; this.btnThemNo.Click += new System.EventHandler(this.btnThemNo_Click);
			this.btnThemPara.Location = new System.Drawing.Point(122, 222); this.btnThemPara.Size = new System.Drawing.Size(95, 28);
			this.btnThemPara.Text = "Thêm (Para)"; this.btnThemPara.Click += new System.EventHandler(this.btnThemPara_Click);
			this.btnSuaNo.Location = new System.Drawing.Point(223, 222); this.btnSuaNo.Size = new System.Drawing.Size(95, 28);
			this.btnSuaNo.Text = "Sửa (No)"; this.btnSuaNo.Click += new System.EventHandler(this.btnSuaNo_Click);
			this.btnSuaPara.Location = new System.Drawing.Point(21, 256); this.btnSuaPara.Size = new System.Drawing.Size(95, 28);
			this.btnSuaPara.Text = "Sửa (Para)"; this.btnSuaPara.Click += new System.EventHandler(this.btnSuaPara_Click);
			this.btnXoaNo.Location = new System.Drawing.Point(122, 256); this.btnXoaNo.Size = new System.Drawing.Size(95, 28);
			this.btnXoaNo.Text = "Xóa (No)"; this.btnXoaNo.Click += new System.EventHandler(this.btnXoaNo_Click);
			this.btnXoaPara.Location = new System.Drawing.Point(223, 256); this.btnXoaPara.Size = new System.Drawing.Size(95, 28);
			this.btnXoaPara.Text = "Xóa (Para)"; this.btnXoaPara.Click += new System.EventHandler(this.btnXoaPara_Click);

			// ListView + filter
			this.lsv.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
				this.colMaSV,this.colTenSV,this.colGioiTinh,this.colNgaySinh,this.colQueQuan,this.colMaLop});
			this.lsv.FullRowSelect = true; this.lsv.GridLines = true; this.lsv.HideSelection = false;
			this.lsv.Location = new System.Drawing.Point(360, 58); this.lsv.MultiSelect = false;
			this.lsv.Name = "lsv"; this.lsv.Size = new System.Drawing.Size(660, 226);
			this.lsv.View = System.Windows.Forms.View.Details;
			this.lsv.SelectedIndexChanged += new System.EventHandler(this.lsv_SelectedIndexChanged);
			this.colMaSV.Text = "Mã SV"; this.colMaSV.Width = 100;
			this.colTenSV.Text = "Tên SV"; this.colTenSV.Width = 150;
			this.colGioiTinh.Text = "Giới tính"; this.colGioiTinh.Width = 70;
			this.colNgaySinh.Text = "Ngày sinh"; this.colNgaySinh.Width = 90;
			this.colQueQuan.Text = "Quê quán"; this.colQueQuan.Width = 150;
			this.colMaLop.Text = "Mã lớp"; this.colMaLop.Width = 80;

			this.groupBox1.Controls.Add(this.cbFilterLop);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Location = new System.Drawing.Point(360, 12);
			this.groupBox1.Size = new System.Drawing.Size(660, 44);
			this.groupBox1.Text = "Lọc danh sách";
			this.label1.AutoSize = true; this.label1.Location = new System.Drawing.Point(12, 19); this.label1.Text = "Theo lớp:";
			this.cbFilterLop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbFilterLop.Location = new System.Drawing.Point(70, 15); this.cbFilterLop.Size = new System.Drawing.Size(220, 21);
			this.cbFilterLop.SelectedIndexChanged += new System.EventHandler(this.cbFilterLop_SelectedIndexChanged);

			// Nhóm thêm lớp
			this.grpLop.Controls.Add(this.btnThemLop);
			this.grpLop.Controls.Add(this.txtTenLopNew);
			this.grpLop.Controls.Add(this.txtMaLopNew);
			this.grpLop.Controls.Add(this.label3);
			this.grpLop.Controls.Add(this.label2);
			this.grpLop.Location = new System.Drawing.Point(21, 296);
			this.grpLop.Size = new System.Drawing.Size(999, 58);
			this.grpLop.Text = "Quản lý Lớp (thêm nhanh)";
			this.label2.AutoSize = true; this.label2.Location = new System.Drawing.Point(12, 26); this.label2.Text = "Mã lớp:";
			this.txtMaLopNew.Location = new System.Drawing.Point(60, 23); this.txtMaLopNew.Size = new System.Drawing.Size(120, 20);
			this.label3.AutoSize = true; this.label3.Location = new System.Drawing.Point(200, 26); this.label3.Text = "Tên lớp:";
			this.txtTenLopNew.Location = new System.Drawing.Point(252, 23); this.txtTenLopNew.Size = new System.Drawing.Size(240, 20);
			this.btnThemLop.Location = new System.Drawing.Point(510, 20); this.btnThemLop.Size = new System.Drawing.Size(95, 24);
			this.btnThemLop.Text = "Thêm lớp"; this.btnThemLop.Click += new System.EventHandler(this.btnThemLop_Click);

			// form
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.ClientSize = new System.Drawing.Size(1036, 366);
			this.Controls.Add(this.grpLop);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.lsv);
			this.Controls.Add(this.btnXoaPara);
			this.Controls.Add(this.btnXoaNo);
			this.Controls.Add(this.btnSuaPara);
			this.Controls.Add(this.btnSuaNo);
			this.Controls.Add(this.btnThemPara);
			this.Controls.Add(this.btnThemNo);
			this.Controls.Add(this.cbMaLop);
			this.Controls.Add(this.txtQueQuan);
			this.Controls.Add(this.dtpNgaySinh);
			this.Controls.Add(this.cbGioiTinh);
			this.Controls.Add(this.txtTenSV);
			this.Controls.Add(this.txtMaSV);
			this.Controls.Add(this.lblMaLop);
			this.Controls.Add(this.lblQueQuan);
			this.Controls.Add(this.lblNgaySinh);
			this.Controls.Add(this.lblGioiTinh);
			this.Controls.Add(this.lblTenSV);
			this.Controls.Add(this.lblMaSV);
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Quản lý sinh viên - CRUD (No Param & Param) + Lọc lớp";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.grpLop.ResumeLayout(false);
			this.grpLop.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		#endregion

		private System.Windows.Forms.Label lblMaSV;
		private System.Windows.Forms.Label lblTenSV;
		private System.Windows.Forms.Label lblGioiTinh;
		private System.Windows.Forms.Label lblNgaySinh;
		private System.Windows.Forms.Label lblQueQuan;
		private System.Windows.Forms.Label lblMaLop;
		private System.Windows.Forms.TextBox txtMaSV;
		private System.Windows.Forms.TextBox txtTenSV;
		private System.Windows.Forms.ComboBox cbGioiTinh;
		private System.Windows.Forms.DateTimePicker dtpNgaySinh;
		private System.Windows.Forms.TextBox txtQueQuan;
		private System.Windows.Forms.ComboBox cbMaLop;
		private System.Windows.Forms.Button btnThemNo;
		private System.Windows.Forms.Button btnThemPara;
		private System.Windows.Forms.Button btnSuaNo;
		private System.Windows.Forms.Button btnSuaPara;
		private System.Windows.Forms.Button btnXoaNo;
		private System.Windows.Forms.Button btnXoaPara;
		private System.Windows.Forms.ListView lsv;
		private System.Windows.Forms.ColumnHeader colMaSV;
		private System.Windows.Forms.ColumnHeader colTenSV;
		private System.Windows.Forms.ColumnHeader colGioiTinh;
		private System.Windows.Forms.ColumnHeader colNgaySinh;
		private System.Windows.Forms.ColumnHeader colQueQuan;
		private System.Windows.Forms.ColumnHeader colMaLop;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.ComboBox cbFilterLop;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.GroupBox grpLop;
		private System.Windows.Forms.Button btnThemLop;
		private System.Windows.Forms.TextBox txtTenLopNew;
		private System.Windows.Forms.TextBox txtMaLopNew;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
	}
}
