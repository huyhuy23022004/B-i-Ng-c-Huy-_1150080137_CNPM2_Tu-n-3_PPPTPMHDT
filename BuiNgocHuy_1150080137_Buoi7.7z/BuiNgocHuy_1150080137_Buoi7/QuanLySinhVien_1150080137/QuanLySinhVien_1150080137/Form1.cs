﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace QuanLySinhVien_1150080137
{
	public partial class Form1 : Form
	{
		// Kết nối LocalDB tới file .mdf trong project
		private readonly string _connStr =
			@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\QuanLySinhVien.mdf;Integrated Security=True";
		private SqlConnection _conn;

		public Form1()
		{
			InitializeComponent();
		}

		private void OpenConn()
		{
			if (_conn == null) _conn = new SqlConnection(_connStr);
			if (_conn.State == ConnectionState.Closed) _conn.Open();
		}

		private void CloseConn()
		{
			if (_conn != null && _conn.State == ConnectionState.Open) _conn.Close();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			cbGioiTinh.Items.Clear();
			cbGioiTinh.Items.Add("Nam");
			cbGioiTinh.Items.Add("Nữ");

			LoadDSLop();         // đổ lớp cho 2 combobox: chọn lớp cho SV và lọc
			LoadList();          // hiển thị DS sinh viên
		}

		// ====== LỚP (Lop) ======
		private void LoadDSLop()
		{
			try
			{
				OpenConn();
				using (var cmd = new SqlCommand("SELECT MaLop, TenLop FROM Lop ORDER BY MaLop", _conn))
				using (var rd = cmd.ExecuteReader())
				{
					cbMaLop.Items.Clear();
					cbFilterLop.Items.Clear();
					cbFilterLop.Items.Add("(Tất cả)");
					while (rd.Read())
					{
						string ma = rd.GetString(0);
						string ten = rd.IsDBNull(1) ? "" : rd.GetString(1);
						cbMaLop.Items.Add($"{ma} - {ten}");
						cbFilterLop.Items.Add($"{ma} - {ten}");
					}
					if (cbFilterLop.Items.Count > 0) cbFilterLop.SelectedIndex = 0;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Lỗi tải danh sách lớp: " + ex.Message);
			}
			finally { CloseConn(); }
		}

		private void btnThemLop_Click(object sender, EventArgs e)
		{
			var ma = txtMaLopNew.Text.Trim();
			var ten = txtTenLopNew.Text.Trim();
			if (string.IsNullOrWhiteSpace(ma)) { MessageBox.Show("Nhập mã lớp!"); return; }
			try
			{
				OpenConn();
				using (var cmd = new SqlCommand("INSERT INTO Lop(MaLop,TenLop) VALUES(@Ma,@Ten)", _conn))
				{
					cmd.Parameters.AddWithValue("@Ma", ma);
					cmd.Parameters.AddWithValue("@Ten", (object)ten ?? DBNull.Value);
					cmd.ExecuteNonQuery();
				}
				MessageBox.Show("Đã thêm lớp.");
				txtMaLopNew.Clear(); txtTenLopNew.Clear();
				LoadDSLop();
			}
			catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601)
			{ MessageBox.Show("Mã lớp đã tồn tại!"); }
			catch (Exception ex) { MessageBox.Show("Lỗi thêm lớp: " + ex.Message); }
			finally { CloseConn(); }
		}

		// ====== HIỂN THỊ DS SINH VIÊN (có lọc theo lớp) ======
		private void LoadList()
		{
			string where = "";
			string maLopFilter = GetSelectedMaLop(cbFilterLop);
			if (!string.IsNullOrEmpty(maLopFilter))
				where = " WHERE MaLop=@MaLop";

			try
			{
				OpenConn();
				using (var cmd = new SqlCommand("SELECT MaSV,TenSV,GioiTinh,NgaySinh,QueQuan,MaLop FROM SinhVien"
												+ where + " ORDER BY MaSV", _conn))
				{
					if (!string.IsNullOrEmpty(maLopFilter))
						cmd.Parameters.AddWithValue("@MaLop", maLopFilter);

					using (var rd = cmd.ExecuteReader())
					{
						lsv.Items.Clear();
						while (rd.Read())
						{
							var item = new ListViewItem(rd.GetString(0)); // MaSV
							item.SubItems.Add(rd.IsDBNull(1) ? "" : rd.GetString(1)); // TenSV
							item.SubItems.Add(rd.IsDBNull(2) ? "" : rd.GetString(2)); // GioiTinh
							item.SubItems.Add(rd.IsDBNull(3) ? "" : rd.GetDateTime(3).ToString("dd/MM/yyyy"));
							item.SubItems.Add(rd.IsDBNull(4) ? "" : rd.GetString(4)); // QueQuan
							item.SubItems.Add(rd.IsDBNull(5) ? "" : rd.GetString(5)); // MaLop
							lsv.Items.Add(item);
						}
					}
				}
			}
			catch (Exception ex) { MessageBox.Show("Lỗi hiển thị: " + ex.Message); }
			finally { CloseConn(); }
		}

		private void cbFilterLop_SelectedIndexChanged(object sender, EventArgs e) => LoadList();

		// Lấy mã lớp từ combobox dạng "MA - Tên"
		private string GetSelectedMaLop(ComboBox cb)
		{
			if (cb.SelectedIndex <= 0 && cb == cbFilterLop) return ""; // (Tất cả)
			if (cb.SelectedIndex < 0 || cb.SelectedItem == null) return "";
			var line = cb.SelectedItem.ToString();
			var ma = line.Split('-')[0].Trim();
			return ma;
		}

		private void lsv_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (lsv.SelectedItems.Count == 0) return;
			var it = lsv.SelectedItems[0];
			txtMaSV.Text = it.SubItems[0].Text;
			txtTenSV.Text = it.SubItems[1].Text;
			cbGioiTinh.Text = it.SubItems[2].Text;
			if (DateTime.TryParse(it.SubItems[3].Text, out var d)) dtpNgaySinh.Value = d;
			txtQueQuan.Text = it.SubItems[4].Text;

			// sync combobox lớp theo giá trị trong list
			var maLop = it.SubItems[5].Text;
			for (int i = 0; i < cbMaLop.Items.Count; i++)
				if (cbMaLop.Items[i].ToString().StartsWith(maLop + " "))
				{ cbMaLop.SelectedIndex = i; break; }
		}

		private void ClearInputs()
		{
			txtMaSV.Clear();
			txtTenSV.Clear();
			cbGioiTinh.SelectedIndex = -1;
			dtpNgaySinh.Value = DateTime.Now;
			txtQueQuan.Clear();
			if (cbMaLop.Items.Count > 0) cbMaLop.SelectedIndex = -1;
			txtMaSV.Focus();
		}

		// ====== THÊM (NO PARAM) ======
		private void btnThemNo_Click(object sender, EventArgs e)
		{
			try
			{
				var maLop = GetSelectedMaLop(cbMaLop);
				if (string.IsNullOrWhiteSpace(txtMaSV.Text) || string.IsNullOrEmpty(maLop))
				{ MessageBox.Show("Nhập Mã SV và chọn Mã lớp!"); return; }

				OpenConn();
				string sql =
					"INSERT INTO SinhVien VALUES ('" + txtMaSV.Text.Trim() + "', N'" + txtTenSV.Text.Trim() +
					"', N'" + cbGioiTinh.Text + "', '" + dtpNgaySinh.Value.ToString("yyyy-MM-dd") +
					"', N'" + txtQueQuan.Text.Trim() + "', N'" + maLop + "')";
				using (var cmd = new SqlCommand(sql, _conn))
				{
					int kq = cmd.ExecuteNonQuery();
					MessageBox.Show(kq > 0 ? "Thêm (No Param) OK" : "Không thêm được");
				}
				LoadList(); ClearInputs();
			}
			catch (SqlException ex) when (ex.Number == 547)
			{ MessageBox.Show("Mã lớp không tồn tại. Hãy thêm lớp hoặc chọn lại!"); }
			catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601)
			{ MessageBox.Show("Mã SV đã tồn tại!"); }
			catch (Exception ex) { MessageBox.Show("Lỗi Thêm (No Param): " + ex.Message); }
			finally { CloseConn(); }
		}

		// ====== THÊM (PARAM) ======
		private void btnThemPara_Click(object sender, EventArgs e)
		{
			try
			{
				var maLop = GetSelectedMaLop(cbMaLop);
				if (string.IsNullOrWhiteSpace(txtMaSV.Text) || string.IsNullOrEmpty(maLop))
				{ MessageBox.Show("Nhập Mã SV và chọn Mã lớp!"); return; }

				OpenConn();
				using (var cmd = new SqlCommand(
						   "INSERT INTO SinhVien (MaSV,TenSV,GioiTinh,NgaySinh,QueQuan,MaLop) " +
						   "VALUES (@MaSV,@TenSV,@GioiTinh,@NgaySinh,@QueQuan,@MaLop)", _conn))
				{
					cmd.Parameters.AddWithValue("@MaSV", txtMaSV.Text.Trim());
					cmd.Parameters.AddWithValue("@TenSV", (object)txtTenSV.Text.Trim() ?? DBNull.Value);
					cmd.Parameters.AddWithValue("@GioiTinh", (object)cbGioiTinh.Text ?? DBNull.Value);
					cmd.Parameters.AddWithValue("@NgaySinh", dtpNgaySinh.Value);
					cmd.Parameters.AddWithValue("@QueQuan", (object)txtQueQuan.Text.Trim() ?? DBNull.Value);
					cmd.Parameters.AddWithValue("@MaLop", maLop);
					cmd.ExecuteNonQuery();
				}
				MessageBox.Show("Thêm (Param) OK");
				LoadList(); ClearInputs();
			}
			catch (SqlException ex) when (ex.Number == 547)
			{ MessageBox.Show("Mã lớp không tồn tại. Hãy thêm lớp hoặc chọn lại!"); }
			catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601)
			{ MessageBox.Show("Mã SV đã tồn tại!"); }
			catch (Exception ex) { MessageBox.Show("Lỗi Thêm (Param): " + ex.Message); }
			finally { CloseConn(); }
		}

		// ====== SỬA (NO PARAM) ======
		private void btnSuaNo_Click(object sender, EventArgs e)
		{
			try
			{
				var maLop = GetSelectedMaLop(cbMaLop);
				if (string.IsNullOrWhiteSpace(txtMaSV.Text))
				{ MessageBox.Show("Nhập/Chọn Mã SV để sửa."); return; }

				OpenConn();
				string sql =
					"UPDATE SinhVien SET TenSV=N'" + txtTenSV.Text.Trim() + "', GioiTinh=N'" + cbGioiTinh.Text +
					"', NgaySinh='" + dtpNgaySinh.Value.ToString("yyyy-MM-dd") + "', QueQuan=N'" +
					txtQueQuan.Text.Trim() + "', MaLop=N'" + maLop +
					"' WHERE MaSV='" + txtMaSV.Text.Trim() + "'";
				using (var cmd = new SqlCommand(sql, _conn))
				{
					int kq = cmd.ExecuteNonQuery();
					MessageBox.Show(kq > 0 ? "Sửa (No Param) OK" : "Không tìm thấy Mã SV");
				}
				LoadList(); ClearInputs();
			}
			catch (SqlException ex) when (ex.Number == 547)
			{ MessageBox.Show("Mã lớp không tồn tại!"); }
			catch (Exception ex) { MessageBox.Show("Lỗi Sửa (No Param): " + ex.Message); }
			finally { CloseConn(); }
		}

		// ====== SỬA (PARAM) ======
		private void btnSuaPara_Click(object sender, EventArgs e)
		{
			try
			{
				var maLop = GetSelectedMaLop(cbMaLop);
				if (string.IsNullOrWhiteSpace(txtMaSV.Text))
				{ MessageBox.Show("Nhập/Chọn Mã SV để sửa."); return; }

				OpenConn();
				using (var cmd = new SqlCommand(
						   "UPDATE SinhVien SET TenSV=@TenSV, GioiTinh=@GioiTinh, NgaySinh=@NgaySinh, " +
						   "QueQuan=@QueQuan, MaLop=@MaLop WHERE MaSV=@MaSV", _conn))
				{
					cmd.Parameters.AddWithValue("@MaSV", txtMaSV.Text.Trim());
					cmd.Parameters.AddWithValue("@TenSV", (object)txtTenSV.Text.Trim() ?? DBNull.Value);
					cmd.Parameters.AddWithValue("@GioiTinh", (object)cbGioiTinh.Text ?? DBNull.Value);
					cmd.Parameters.AddWithValue("@NgaySinh", dtpNgaySinh.Value);
					cmd.Parameters.AddWithValue("@QueQuan", (object)txtQueQuan.Text.Trim() ?? DBNull.Value);
					cmd.Parameters.AddWithValue("@MaLop", (object)maLop ?? DBNull.Value);
					int kq = cmd.ExecuteNonQuery();
					MessageBox.Show(kq > 0 ? "Sửa (Param) OK" : "Không tìm thấy Mã SV");
				}
				LoadList(); ClearInputs();
			}
			catch (SqlException ex) when (ex.Number == 547)
			{ MessageBox.Show("Mã lớp không tồn tại!"); }
			catch (Exception ex) { MessageBox.Show("Lỗi Sửa (Param): " + ex.Message); }
			finally { CloseConn(); }
		}

		// ====== XÓA (NO PARAM) ======
		private void btnXoaNo_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrWhiteSpace(txtMaSV.Text))
			{ MessageBox.Show("Nhập/Chọn Mã SV để xóa."); return; }
			if (MessageBox.Show($"Xóa {txtMaSV.Text.Trim()} ?", "Xác nhận",
					MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;

			try
			{
				OpenConn();
				string sql = "DELETE FROM SinhVien WHERE MaSV='" + txtMaSV.Text.Trim() + "'";
				using (var cmd = new SqlCommand(sql, _conn))
				{
					int kq = cmd.ExecuteNonQuery();
					MessageBox.Show(kq > 0 ? "Xóa (No Param) OK" : "Không tìm thấy Mã SV");
				}
				LoadList(); ClearInputs();
			}
			catch (Exception ex) { MessageBox.Show("Lỗi Xóa (No Param): " + ex.Message); }
			finally { CloseConn(); }
		}

		// ====== XÓA (PARAM) ======
		private void btnXoaPara_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrWhiteSpace(txtMaSV.Text))
			{ MessageBox.Show("Nhập/Chọn Mã SV để xóa."); return; }
			if (MessageBox.Show($"Xóa {txtMaSV.Text.Trim()} ?", "Xác nhận",
					MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;

			try
			{
				OpenConn();
				using (var cmd = new SqlCommand("DELETE FROM SinhVien WHERE MaSV=@MaSV", _conn))
				{
					cmd.Parameters.AddWithValue("@MaSV", txtMaSV.Text.Trim());
					int kq = cmd.ExecuteNonQuery();
					MessageBox.Show(kq > 0 ? "Xóa (Param) OK" : "Không tìm thấy Mã SV");
				}
				LoadList(); ClearInputs();
			}
			catch (Exception ex) { MessageBox.Show("Lỗi Xóa (Param): " + ex.Message); }
			finally { CloseConn(); }
		}
	}
}
