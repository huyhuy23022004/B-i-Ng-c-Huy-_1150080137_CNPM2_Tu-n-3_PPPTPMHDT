﻿INSERT INTO Lop (MaLop, TenLop) VALUES
  (N'CNPM1', N'Công nghệ phần mềm 1'),
  (N'CNPM2', N'Công nghệ phần mềm 2');

-- kiểm tra
SELECT * FROM Lop WHERE MaLop IN (N'CNPM1', N'CNPM2');
