﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Lab7_WinForm
{
    public partial class Form1 : Form
    {
        
        private string strCon = @"Data Source=WIN-4MTJNF8B2GT;Initial Catalog=YH_HdtDB;User ID=sa;Password=1234;Encrypt=False;TrustServerCertificate=True;";
        private SqlConnection sqlCon = null;
        private SqlDataAdapter adapter = null;
        private DataSet ds = null;
        private int vt = -1;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            HienThiDuLieu();
            XoaDuLieuForm();
        }

        private void MoKetnoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);

            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        private void DongKetnoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        private void XoaDuLieuForm()
        {
            txtMaXB.Text = txtTenXB.Text = txtDiaChi.Text = "";
            vt = -1;
        }

        private void HienThiDuLieu()
        {
            try
            {
                MoKetnoi();
                string query = "SELECT * FROM dbo.haXuatBan";
                adapter = new SqlDataAdapter(query, sqlCon);
                SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                ds = new DataSet();
                adapter.Fill(ds, "tblhaXuatBan");
                dgvDanhSach.DataSource = ds.Tables["tblhaXuatBan"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetnoi();
            }
        }

        private void btnHienThi_Click(object sender, EventArgs e)
        {
            HienThiDuLieu();
        }

        private void btnThemDL_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaXB.Text))
            {
                MessageBox.Show("Vui lòng nhập mã XB (khóa chính).");
                return;
            }

            try
            {
                DataRow row = ds.Tables["tblhaXuatBan"].NewRow();
                row["XB"] = txtMaXB.Text.Trim();
                row["TenXB"] = txtTenXB.Text.Trim();
                row["DiaChi"] = txtDiaChi.Text.Trim();

                ds.Tables["tblhaXuatBan"].Rows.Add(row);

                int kq = adapter.Update(ds.Tables["tblhaXuatBan"]);
                if (kq > 0)
                {
                    MessageBox.Show("Thêm dữ liệu thành công!");
                    HienThiDuLieu();
                    XoaDuLieuForm();
                }
                else
                {
                    MessageBox.Show("Thêm dữ liệu không thành công!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm: " + ex.Message);
            }
        }

        private void dgvDanhSach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            vt = e.RowIndex;
            if (vt == -1 || ds == null || ds.Tables["tblhaXuatBan"].Rows.Count <= vt) return;

            DataRow row = ds.Tables["tblhaXuatBan"].Rows[vt];
            txtMaXB.Text = row["XB"].ToString().Trim();
            txtTenXB.Text = row["TenXB"].ToString().Trim();
            txtDiaChi.Text = row["DiaChi"].ToString().Trim();
        }

        private void btnChinhSuaThongTin_Click(object sender, EventArgs e)
        {
            if (vt == -1)
            {
                MessageBox.Show("Bạn chưa chọn dữ liệu để chỉnh sửa!");
                return;
            }

            try
            {
                DataRow row = ds.Tables["tblhaXuatBan"].Rows[vt];
                row.BeginEdit();
                row["XB"] = txtMaXB.Text.Trim();
                row["TenXB"] = txtTenXB.Text.Trim();
                row["DiaChi"] = txtDiaChi.Text.Trim();
                row.EndEdit();

                int kq = adapter.Update(ds.Tables["tblhaXuatBan"]);
                if (kq > 0)
                {
                    MessageBox.Show("Chỉnh sửa dữ liệu thành công!");
                    HienThiDuLieu();
                    XoaDuLieuForm();
                }
                else
                {
                    MessageBox.Show("Chỉnh sửa dữ liệu không thành công!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi chỉnh sửa: " + ex.Message);
            }
        }

        private void btnXoaDuLieu_Click(object sender, EventArgs e)
        {
            if (vt == -1)
            {
                MessageBox.Show("Bạn chưa chọn dữ liệu để xóa!");
                return;
            }

            DialogResult result = MessageBox.Show("Bạn có thực sự muốn xóa hay không?", "Cảnh báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                try
                {
                    DataRow row = ds.Tables["tblhaXuatBan"].Rows[vt];
                    row.Delete();
                    int kq = adapter.Update(ds.Tables["tblhaXuatBan"]);
                    if (kq > 0)
                    {
                        MessageBox.Show("Xóa dữ liệu thành công!");
                        HienThiDuLieu();
                        XoaDuLieuForm();
                    }
                    else
                    {
                        MessageBox.Show("Xóa dữ liệu không thành công!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi xóa: " + ex.Message);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            XoaDuLieuForm();
        }
    }
}
