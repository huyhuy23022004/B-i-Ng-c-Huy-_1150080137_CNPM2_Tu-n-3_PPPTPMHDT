﻿-- TẠO DATABASE (nếu chưa có)
IF DB_ID(N'YH_HdtDB') IS NULL
BEGIN
    CREATE DATABASE YH_HdtDB;
END
GO

USE YH_HdtDB;
GO

-- TẠO BẢNG haXuatBan (nếu chưa có)
IF OBJECT_ID(N'dbo.haXuatBan', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.haXuatBan (
        XB      VARCHAR(50) PRIMARY KEY,
        TenXB   NVARCHAR(200) NULL,
        DiaChi  NVARCHAR(300) NULL
    );
END
GO
