﻿using System;

using System.Collections.Generic;

using System.ComponentModel;

using System.Data;

using System.Drawing;

using System.IO;

using System.Linq;

using System.Text;

using System.Threading.Tasks;

using System.Windows.Forms;



namespace lab3_thuchanh1_1150080137

{

	public partial class Form1 : Form

	{

		// Data

		private Dictionary<string, int> orderItems = new Dictionary<string, int>();



		public Form1()

		{

			InitializeComponent();

		}



		private void MenuButton_Click(object sender, EventArgs e)

		{

			if (sender is Button btn)

			{

				string item = btn.Text;



				if (orderItems.ContainsKey(item))

					orderItems[item]++;

				else

					orderItems[item] = 1;



				RefreshOrderListView();

			}

		}



		private void RefreshOrderListView()

		{

			lvOrder.BeginUpdate();

			lvOrder.Items.Clear();

			foreach (var kv in orderItems)

			{

				var lvi = new ListViewItem(kv.Key);

				lvi.SubItems.Add(kv.Value.ToString());

				lvOrder.Items.Add(lvi);

			}

			lvOrder.EndUpdate();

		}



		private void BtnClear_Click(object sender, EventArgs e)

		{

			orderItems.Clear();

			RefreshOrderListView();

			cmbTables.SelectedIndex = -1;

		}



		private void BtnOrder_Click(object sender, EventArgs e)

		{

			if (cmbTables.SelectedItem == null)

			{

				MessageBox.Show("Vui lòng chọn bàn trước khi Order.", "Chưa chọn bàn", MessageBoxButtons.OK, MessageBoxIcon.Warning);

				return;

			}



			if (orderItems.Count == 0)

			{

				MessageBox.Show("Chưa có món nào để order.", "Danh sách rỗng", MessageBoxButtons.OK, MessageBoxIcon.Information);

				return;

			}



			try

			{

				string folder = AppDomain.CurrentDomain.BaseDirectory;

				string fileName = $"order_{DateTime.Now:yyyyMMdd_HHmmss}.txt";

				string path = Path.Combine(folder, fileName);



				var sb = new StringBuilder();

				sb.AppendLine($"Bàn: {cmbTables.SelectedItem}");

				sb.AppendLine("Các món:");

				foreach (var kv in orderItems)

				{

					sb.AppendLine($"{kv.Key} - {kv.Value}");

				}



				File.WriteAllText(path, sb.ToString(), Encoding.UTF8);



				MessageBox.Show($"Ghi file order thành công:\n{path}", "Hoàn thành", MessageBoxButtons.OK, MessageBoxIcon.Information);



				// After ordering, clear current order

				orderItems.Clear();

				RefreshOrderListView();

				cmbTables.SelectedIndex = -1;

			}

			catch (Exception ex)

			{

				MessageBox.Show("Lỗi khi ghi file: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);

			}

		}



		private void lblTitle_Click(object sender, EventArgs e)

		{



		}



		private void lblStudentInfo_Click(object sender, EventArgs e)

		{



		}



		private void Form1_Load(object sender, EventArgs e)

		{



		}

	}

}