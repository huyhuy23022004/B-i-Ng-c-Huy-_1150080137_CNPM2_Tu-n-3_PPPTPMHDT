﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace Lab06_QuanLyNhaXuatBan
{
    public partial class Form1 : Form
    {
        // Tự động trỏ tới file .mdf trong thư mục project/bin/Debug|Release nếu bạn để file tại root project.
        private static string DbPath => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\QuanLyBanSach.mdf");
        private readonly string _strCon;

        private SqlConnection _sqlCon;

        public Form1()
        {
            InitializeComponent();

            // Kết nối LocalDB kèm AttachDbFilename
            _strCon = @"Data Source=(LocalDB)\MSSQLLocalDB;
            AttachDbFilename=|DataDirectory|\QuanLyBanSach.mdf;
            Integrated Security=True;Connect Timeout=30;";

        }

        #region Helpers mở/đóng kết nối
        private void MoKetNoi()
        {
            if (_sqlCon == null) _sqlCon = new SqlConnection(_strCon);
            if (_sqlCon.State == ConnectionState.Closed) _sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (_sqlCon != null && _sqlCon.State == ConnectionState.Open)
                _sqlCon.Close();
        }
        #endregion

        #region Load danh sách (Thực hành 1)
        private void HienThiDanhSachNXB()
        {
            try
            {
                MoKetNoi();
                using (var cmd = new SqlCommand(@"SELECT MaNXB, TenNXB, DiaChi FROM dbo.NhaXuatBan ORDER BY MaNXB", _sqlCon))
                using (var rd = cmd.ExecuteReader())
                {
                    lsvDanhSach.Items.Clear();
                    while (rd.Read())
                    {
                        string ma = rd.GetString(0).Trim();
                        string ten = rd.IsDBNull(1) ? "" : rd.GetString(1);
                        string diachi = rd.IsDBNull(2) ? "" : rd.GetString(2);

                        var item = new ListViewItem(ma);
                        item.SubItems.Add(ten);
                        item.SubItems.Add(diachi);
                        lsvDanhSach.Items.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        private void HienThiThongTinNXBTheoMa(string maNXB)
        {
            if (string.IsNullOrWhiteSpace(maNXB)) return;

            try
            {
                MoKetNoi();
                using (var cmd = new SqlCommand(
                           @"SELECT MaNXB, TenNXB, DiaChi FROM dbo.NhaXuatBan WHERE MaNXB = @ma", _sqlCon))
                {
                    cmd.Parameters.Add("@ma", SqlDbType.Char, 10).Value = maNXB;

                    using (var rd = cmd.ExecuteReader())
                    {
                        txtMaNXB.Text = txtTenNXB.Text = txtDiaChi.Text = "";
                        if (rd.Read())
                        {
                            txtMaNXB.Text = rd.GetString(0).Trim();
                            txtTenNXB.Text = rd.IsDBNull(1) ? "" : rd.GetString(1);
                            txtDiaChi.Text = rd.IsDBNull(2) ? "" : rd.GetString(2);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị chi tiết: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }
        #endregion

        #region Thêm (Thực hành 2)
        private void ThemNXB(string ma, string ten, string diachi)
        {
            if (string.IsNullOrWhiteSpace(ma))
            {
                MessageBox.Show("Mã NXB không được trống!");
                return;
            }

            try
            {
                MoKetNoi();
                using (var cmd = new SqlCommand(
                           @"INSERT INTO dbo.NhaXuatBan(MaNXB, TenNXB, DiaChi)
                             VALUES(@ma, @ten, @diachi)", _sqlCon))
                {
                    cmd.Parameters.Add("@ma", SqlDbType.Char, 10).Value = ma.Trim();
                    cmd.Parameters.Add("@ten", SqlDbType.NVarChar, 100).Value = (object)ten ?? DBNull.Value;
                    cmd.Parameters.Add("@diachi", SqlDbType.NVarChar, 500).Value = (object)diachi ?? DBNull.Value;

                    int kq = cmd.ExecuteNonQuery();
                    if (kq > 0)
                    {
                        MessageBox.Show("Thêm dữ liệu thành công!");
                        HienThiDanhSachNXB();
                        ClearInputs();
                    }
                }
            }
            catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601) // duplicate key
            {
                MessageBox.Show("Mã NXB đã tồn tại!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }
        #endregion

        #region Sửa (Thực hành 3)
        private void SuaNXB(string ma, string ten, string diachi)
        {
            if (string.IsNullOrWhiteSpace(ma))
            {
                MessageBox.Show("Chọn bản ghi để sửa (Mã NXB)!");
                return;
            }

            try
            {
                MoKetNoi();
                using (var cmd = new SqlCommand(
                           @"UPDATE dbo.NhaXuatBan
                             SET TenNXB = @ten, DiaChi = @diachi
                             WHERE MaNXB = @ma", _sqlCon))
                {
                    cmd.Parameters.Add("@ma", SqlDbType.Char, 10).Value = ma.Trim();
                    cmd.Parameters.Add("@ten", SqlDbType.NVarChar, 100).Value = (object)ten ?? DBNull.Value;
                    cmd.Parameters.Add("@diachi", SqlDbType.NVarChar, 500).Value = (object)diachi ?? DBNull.Value;

                    int kq = cmd.ExecuteNonQuery();
                    if (kq > 0)
                    {
                        MessageBox.Show("Sửa dữ liệu thành công!");
                        HienThiDanhSachNXB();
                        SelectItemByKey(ma);
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy Mã NXB để sửa.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }
        #endregion

        #region Xóa (Thực hành 4)
        private void XoaNXB(string ma)
        {
            if (string.IsNullOrWhiteSpace(ma))
            {
                MessageBox.Show("Chọn bản ghi để xóa!");
                return;
            }

            if (MessageBox.Show($"Bạn chắc chắn xóa NXB [{ma}] ?", "Xác nhận",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            try
            {
                MoKetNoi();

                // Chặn xóa nếu còn sách tham chiếu
                using (var check = new SqlCommand(@"SELECT COUNT(*) FROM dbo.Sach WHERE MaNXB = @ma", _sqlCon))
                {
                    check.Parameters.Add("@ma", SqlDbType.Char, 10).Value = ma.Trim();
                    int cnt = Convert.ToInt32(check.ExecuteScalar());
                    if (cnt > 0)
                    {
                        MessageBox.Show("Không thể xóa do còn Sách tham chiếu (khóa ngoại).");
                        return;
                    }
                }

                using (var cmd = new SqlCommand(@"DELETE FROM dbo.NhaXuatBan WHERE MaNXB = @ma", _sqlCon))
                {
                    cmd.Parameters.Add("@ma", SqlDbType.Char, 10).Value = ma.Trim();
                    int kq = cmd.ExecuteNonQuery();
                    if (kq > 0)
                    {
                        MessageBox.Show("Xóa dữ liệu thành công!");
                        HienThiDanhSachNXB();
                        ClearInputs();
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy Mã NXB để xóa.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }
        #endregion

        #region Tiện ích UI
        private void ClearInputs()
        {
            txtMaNXB.Text = "";
            txtTenNXB.Text = "";
            txtDiaChi.Text = "";
            txtMaNXB.Focus();
        }

        private void SelectItemByKey(string ma)
        {
            foreach (ListViewItem it in lsvDanhSach.Items)
            {
                if (string.Equals(it.Text.Trim(), ma.Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    it.Selected = true;
                    it.Focused = true;
                    it.EnsureVisible();
                    lsvDanhSach.Select();
                    return;
                }
            }
        }
        #endregion

        #region Sự kiện
        private void Form1_Load(object sender, EventArgs e)
        {
            HienThiDanhSachNXB();
            txtMaNXB.Focus();
        }

        private void lsvDanhSach_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvDanhSach.SelectedItems.Count == 0) return;
            var lvi = lsvDanhSach.SelectedItems[0];
            string ma = lvi.SubItems[0].Text;
            HienThiThongTinNXBTheoMa(ma);
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            ThemNXB(txtMaNXB.Text, txtTenNXB.Text, txtDiaChi.Text);
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            SuaNXB(txtMaNXB.Text, txtTenNXB.Text, txtDiaChi.Text);
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            XoaNXB(txtMaNXB.Text);
        }

        private void btnReload_Click(object sender, EventArgs e)
        {
            HienThiDanhSachNXB();
        }
        #endregion
    }
}
