﻿INSERT INTO dbo.NhaXuatBan(MaNXB, TenNXB, DiaChi) VALUES
('NXB01', N'Giáo Dục Việt Nam', N'Hà Nội'),
('NXB02', N'Trẻ', N'TP. Hồ Chí Minh'),
('NXB03', N'Khoa Học Kỹ Thuật', N'Đà Nẵng');

INSERT INTO dbo.Sach(MaSach, TenSach, MaNXB, TenTacGia, NamXuatBan, GhiChu) VALUES
('S01', N'Lập Trình C#', 'NXB01', N'Nguyễn Văn A', '2022-05-01', N'Sách cơ bản'),
('S02', N'Lập Trình Java', 'NXB02', N'Trần Thị B', '2023-03-10', N'Sách nâng cao'),
('S03', N'Thiết Kế CSDL', 'NXB03', N'Lê Văn C', '2021-09-15', N'Tài liệu học tập');
