﻿namespace ApDung4
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lstMatHang = new System.Windows.Forms.ListBox();
			this.lstDaChon = new System.Windows.Forms.ListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.btnChuyen1 = new System.Windows.Forms.Button();
			this.btnChuyenAll = new System.Windows.Forms.Button();
			this.btnXoa1 = new System.Windows.Forms.Button();
			this.btnXoaAll = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lstMatHang
			// 
			this.lstMatHang.FormattingEnabled = true;
			this.lstMatHang.Items.AddRange(new object[] {
            "CPU",
            "MainBoard",
            "RAM",
            "Keyboard",
            "Mouse",
            "NIC",
            "FAN"});
			this.lstMatHang.Location = new System.Drawing.Point(2, 39);
			this.lstMatHang.Name = "lstMatHang";
			this.lstMatHang.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.lstMatHang.Size = new System.Drawing.Size(330, 394);
			this.lstMatHang.TabIndex = 0;
			// 
			// lstDaChon
			// 
			this.lstDaChon.FormattingEnabled = true;
			this.lstDaChon.Location = new System.Drawing.Point(470, 39);
			this.lstDaChon.Name = "lstDaChon";
			this.lstDaChon.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.lstDaChon.Size = new System.Drawing.Size(330, 394);
			this.lstDaChon.TabIndex = 1;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(-2, 12);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(127, 13);
			this.label1.TabIndex = 2;
			this.label1.Text = "Danh sách các mặt hàng";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(466, 12);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(117, 13);
			this.label2.TabIndex = 3;
			this.label2.Text = "Các mặt hàng lựa chọn";
			// 
			// panel1
			// 
			this.panel1.Location = new System.Drawing.Point(1, 12);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(340, 434);
			this.panel1.TabIndex = 4;
			// 
			// panel2
			// 
			this.panel2.Location = new System.Drawing.Point(459, 12);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(340, 434);
			this.panel2.TabIndex = 5;
			// 
			// btnChuyen1
			// 
			this.btnChuyen1.Location = new System.Drawing.Point(371, 120);
			this.btnChuyen1.Name = "btnChuyen1";
			this.btnChuyen1.Size = new System.Drawing.Size(75, 23);
			this.btnChuyen1.TabIndex = 6;
			this.btnChuyen1.Text = ">";
			this.btnChuyen1.UseVisualStyleBackColor = true;
			this.btnChuyen1.Click += new System.EventHandler(this.btnChuyen1_Click);
			// 
			// btnChuyenAll
			// 
			this.btnChuyenAll.Location = new System.Drawing.Point(371, 177);
			this.btnChuyenAll.Name = "btnChuyenAll";
			this.btnChuyenAll.Size = new System.Drawing.Size(75, 23);
			this.btnChuyenAll.TabIndex = 7;
			this.btnChuyenAll.Text = ">>";
			this.btnChuyenAll.UseVisualStyleBackColor = true;
			this.btnChuyenAll.Click += new System.EventHandler(this.btnChuyenAll_Click);
			// 
			// btnXoa1
			// 
			this.btnXoa1.Location = new System.Drawing.Point(371, 243);
			this.btnXoa1.Name = "btnXoa1";
			this.btnXoa1.Size = new System.Drawing.Size(75, 23);
			this.btnXoa1.TabIndex = 8;
			this.btnXoa1.Text = "<";
			this.btnXoa1.UseVisualStyleBackColor = true;
			this.btnXoa1.Click += new System.EventHandler(this.btnXoa1_Click);
			// 
			// btnXoaAll
			// 
			this.btnXoaAll.Location = new System.Drawing.Point(371, 305);
			this.btnXoaAll.Name = "btnXoaAll";
			this.btnXoaAll.Size = new System.Drawing.Size(75, 23);
			this.btnXoaAll.TabIndex = 9;
			this.btnXoaAll.Text = "<<";
			this.btnXoaAll.UseVisualStyleBackColor = true;
			this.btnXoaAll.Click += new System.EventHandler(this.btnXoaAll_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.btnXoaAll);
			this.Controls.Add(this.btnXoa1);
			this.Controls.Add(this.btnChuyenAll);
			this.Controls.Add(this.btnChuyen1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.lstDaChon);
			this.Controls.Add(this.lstMatHang);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panel2);
			this.Name = "Form1";
			this.Text = "Bài tập 7";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ListBox lstMatHang;
		private System.Windows.Forms.ListBox lstDaChon;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button btnChuyen1;
		private System.Windows.Forms.Button btnChuyenAll;
		private System.Windows.Forms.Button btnXoa1;
		private System.Windows.Forms.Button btnXoaAll;
	}
}

