﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApDung4
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();

			// Khởi tạo dữ liệu ban đầu cho ListBox lstMatHang
			lstMatHang.Items.AddRange(new object[]
			{
				"CPU", "MainBoard", "RAM", "Keyboard", "Mouse", "NIC", "FAN"
			});

			lstMatHang.SelectionMode = SelectionMode.MultiExtended;
			lstDaChon.SelectionMode = SelectionMode.MultiExtended;
		}

		// Nút > : chuyển các phần tử đang chọn sang lstDaChon
		private void btnChuyen1_Click(object sender, EventArgs e)
		{
			while (lstMatHang.SelectedItems.Count > 0)
			{
				object item = lstMatHang.SelectedItems[0];
				lstDaChon.Items.Add(item);
				lstMatHang.Items.Remove(item);
			}
		}

		// Nút >> : chuyển toàn bộ sang lstDaChon
		private void btnChuyenAll_Click(object sender, EventArgs e)
		{
			foreach (object item in lstMatHang.Items)
			{
				lstDaChon.Items.Add(item);
			}
			lstMatHang.Items.Clear();
		}

		// Nút < : chuyển các phần tử đang chọn sang lstMatHang
		private void btnXoa1_Click(object sender, EventArgs e)
		{
			while (lstDaChon.SelectedItems.Count > 0)
			{
				object item = lstDaChon.SelectedItems[0];
				lstMatHang.Items.Add(item);
				lstDaChon.Items.Remove(item);
			}
		}

		// Nút << : chuyển toàn bộ sang lstMatHang
		private void btnXoaAll_Click(object sender, EventArgs e)
		{
			foreach (object item in lstDaChon.Items)
			{
				lstMatHang.Items.Add(item);
			}
			lstDaChon.Items.Clear();
		}
	}
}
