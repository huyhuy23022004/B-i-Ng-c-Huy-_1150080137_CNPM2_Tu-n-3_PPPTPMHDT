﻿namespace ThucHanh2
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.txtTenKH = new System.Windows.Forms.TextBox();
			this.panel4 = new System.Windows.Forms.Panel();
			this.label4 = new System.Windows.Forms.Label();
			this.err = new System.Windows.Forms.ErrorProvider(this.components);
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.chkLayCaoRang = new System.Windows.Forms.CheckBox();
			this.chkTayTrangRang = new System.Windows.Forms.CheckBox();
			this.chkHanRang = new System.Windows.Forms.CheckBox();
			this.chkBeRang = new System.Windows.Forms.CheckBox();
			this.chkBocRang = new System.Windows.Forms.CheckBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.nupHanRang = new System.Windows.Forms.NumericUpDown();
			this.nupBocRang = new System.Windows.Forms.NumericUpDown();
			this.nupBeRang = new System.Windows.Forms.NumericUpDown();
			this.txtThanhTien = new System.Windows.Forms.TextBox();
			this.btnTinhTien = new System.Windows.Forms.Button();
			this.btnThoat = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.err)).BeginInit();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.nupHanRang)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nupBocRang)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nupBeRang)).BeginInit();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.Lime;
			this.panel1.Controls.Add(this.label1);
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(800, 76);
			this.panel1.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Lime;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.SystemColors.Control;
			this.label1.Location = new System.Drawing.Point(181, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(472, 31);
			this.label1.TabIndex = 0;
			this.label1.Text = "PHÒNG KHÁM NHA KHOA HẢI ÂU";
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.txtTenKH);
			this.panel2.Location = new System.Drawing.Point(0, 82);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(800, 66);
			this.panel2.TabIndex = 1;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(12, 79);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 19);
			this.label2.TabIndex = 0;
			this.label2.Text = "Tên khách hàng:";
			// 
			// txtTenKH
			// 
			this.txtTenKH.Location = new System.Drawing.Point(264, 20);
			this.txtTenKH.Name = "txtTenKH";
			this.txtTenKH.Size = new System.Drawing.Size(299, 20);
			this.txtTenKH.TabIndex = 0;
			this.txtTenKH.Validating += new System.ComponentModel.CancelEventHandler(this.txtTenKH_Validating);
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.btnThoat);
			this.panel4.Controls.Add(this.btnTinhTien);
			this.panel4.Controls.Add(this.txtThanhTien);
			this.panel4.Controls.Add(this.label4);
			this.panel4.Location = new System.Drawing.Point(0, 335);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(800, 112);
			this.panel4.TabIndex = 3;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(12, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(93, 19);
			this.label4.TabIndex = 0;
			this.label4.Text = "Chức năng:";
			// 
			// err
			// 
			this.err.ContainerControl = this;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.nupBeRang);
			this.groupBox1.Controls.Add(this.nupBocRang);
			this.groupBox1.Controls.Add(this.nupHanRang);
			this.groupBox1.Controls.Add(this.label8);
			this.groupBox1.Controls.Add(this.label7);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.chkBocRang);
			this.groupBox1.Controls.Add(this.chkBeRang);
			this.groupBox1.Controls.Add(this.chkHanRang);
			this.groupBox1.Controls.Add(this.chkTayTrangRang);
			this.groupBox1.Controls.Add(this.chkLayCaoRang);
			this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox1.Location = new System.Drawing.Point(0, 154);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(800, 178);
			this.groupBox1.TabIndex = 4;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Dịch vụ tại phòng khám";
			// 
			// chkLayCaoRang
			// 
			this.chkLayCaoRang.AutoSize = true;
			this.chkLayCaoRang.Location = new System.Drawing.Point(187, 26);
			this.chkLayCaoRang.Name = "chkLayCaoRang";
			this.chkLayCaoRang.Size = new System.Drawing.Size(122, 23);
			this.chkLayCaoRang.TabIndex = 0;
			this.chkLayCaoRang.Text = "Lấy cao răng";
			this.chkLayCaoRang.UseVisualStyleBackColor = true;
			// 
			// chkTayTrangRang
			// 
			this.chkTayTrangRang.AutoSize = true;
			this.chkTayTrangRang.Location = new System.Drawing.Point(187, 55);
			this.chkTayTrangRang.Name = "chkTayTrangRang";
			this.chkTayTrangRang.Size = new System.Drawing.Size(136, 23);
			this.chkTayTrangRang.TabIndex = 1;
			this.chkTayTrangRang.Text = "Tẩy trắng răng";
			this.chkTayTrangRang.UseVisualStyleBackColor = true;
			// 
			// chkHanRang
			// 
			this.chkHanRang.AutoSize = true;
			this.chkHanRang.Location = new System.Drawing.Point(187, 84);
			this.chkHanRang.Name = "chkHanRang";
			this.chkHanRang.Size = new System.Drawing.Size(96, 23);
			this.chkHanRang.TabIndex = 2;
			this.chkHanRang.Text = "Hàn răng";
			this.chkHanRang.UseVisualStyleBackColor = true;
			// 
			// chkBeRang
			// 
			this.chkBeRang.AutoSize = true;
			this.chkBeRang.Location = new System.Drawing.Point(187, 113);
			this.chkBeRang.Name = "chkBeRang";
			this.chkBeRang.Size = new System.Drawing.Size(86, 23);
			this.chkBeRang.TabIndex = 3;
			this.chkBeRang.Text = "Bẻ răng";
			this.chkBeRang.UseVisualStyleBackColor = true;
			// 
			// chkBocRang
			// 
			this.chkBocRang.AutoSize = true;
			this.chkBocRang.Location = new System.Drawing.Point(187, 142);
			this.chkBocRang.Name = "chkBocRang";
			this.chkBocRang.Size = new System.Drawing.Size(95, 23);
			this.chkBocRang.TabIndex = 4;
			this.chkBocRang.Text = "Bọc răng";
			this.chkBocRang.UseVisualStyleBackColor = true;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(508, 30);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(116, 19);
			this.label3.TabIndex = 5;
			this.label3.Text = "50.000đ/2 hàm";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(508, 59);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(125, 19);
			this.label5.TabIndex = 6;
			this.label5.Text = "100.000đ/2 hàm";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(508, 88);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(128, 19);
			this.label6.TabIndex = 7;
			this.label6.Text = "100.000đ/1 răng";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(508, 117);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(119, 19);
			this.label7.TabIndex = 8;
			this.label7.Text = "10.000đ/1 răng";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(508, 146);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(141, 19);
			this.label8.TabIndex = 9;
			this.label8.Text = "1.000.000đ/1 răng";
			// 
			// nupHanRang
			// 
			this.nupHanRang.Location = new System.Drawing.Point(688, 83);
			this.nupHanRang.Name = "nupHanRang";
			this.nupHanRang.Size = new System.Drawing.Size(77, 27);
			this.nupHanRang.TabIndex = 10;
			// 
			// nupBocRang
			// 
			this.nupBocRang.Location = new System.Drawing.Point(688, 138);
			this.nupBocRang.Name = "nupBocRang";
			this.nupBocRang.Size = new System.Drawing.Size(77, 27);
			this.nupBocRang.TabIndex = 11;
			// 
			// nupBeRang
			// 
			this.nupBeRang.Location = new System.Drawing.Point(688, 109);
			this.nupBeRang.Name = "nupBeRang";
			this.nupBeRang.Size = new System.Drawing.Size(77, 27);
			this.nupBeRang.TabIndex = 12;
			// 
			// txtThanhTien
			// 
			this.txtThanhTien.Location = new System.Drawing.Point(264, 42);
			this.txtThanhTien.Name = "txtThanhTien";
			this.txtThanhTien.ReadOnly = true;
			this.txtThanhTien.Size = new System.Drawing.Size(299, 20);
			this.txtThanhTien.TabIndex = 1;
			// 
			// btnTinhTien
			// 
			this.btnTinhTien.Location = new System.Drawing.Point(141, 39);
			this.btnTinhTien.Name = "btnTinhTien";
			this.btnTinhTien.Size = new System.Drawing.Size(75, 23);
			this.btnTinhTien.TabIndex = 2;
			this.btnTinhTien.Text = "Tính tiền";
			this.btnTinhTien.UseVisualStyleBackColor = true;
			this.btnTinhTien.Click += new System.EventHandler(this.btnTinhTien_Click);
			// 
			// btnThoat
			// 
			this.btnThoat.Location = new System.Drawing.Point(616, 39);
			this.btnThoat.Name = "btnThoat";
			this.btnThoat.Size = new System.Drawing.Size(75, 23);
			this.btnThoat.TabIndex = 3;
			this.btnThoat.Text = "Thoát";
			this.btnThoat.UseVisualStyleBackColor = true;
			this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.panel4);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.panel4.ResumeLayout(false);
			this.panel4.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.err)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.nupHanRang)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nupBocRang)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nupBeRang)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.TextBox txtTenKH;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ErrorProvider err;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.CheckBox chkBocRang;
		private System.Windows.Forms.CheckBox chkBeRang;
		private System.Windows.Forms.CheckBox chkHanRang;
		private System.Windows.Forms.CheckBox chkTayTrangRang;
		private System.Windows.Forms.CheckBox chkLayCaoRang;
		private System.Windows.Forms.NumericUpDown nupBeRang;
		private System.Windows.Forms.NumericUpDown nupBocRang;
		private System.Windows.Forms.NumericUpDown nupHanRang;
		private System.Windows.Forms.Button btnThoat;
		private System.Windows.Forms.Button btnTinhTien;
		private System.Windows.Forms.TextBox txtThanhTien;
	}
}

