﻿namespace ApDung1
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnTim = new System.Windows.Forms.Button();
			this.btnThoat = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.txtA = new System.Windows.Forms.TextBox();
			this.txtB = new System.Windows.Forms.TextBox();
			this.txtKetQua = new System.Windows.Forms.TextBox();
			this.radUSCLN = new System.Windows.Forms.RadioButton();
			this.radBSCNN = new System.Windows.Forms.RadioButton();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel3.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnTim
			// 
			this.btnTim.Location = new System.Drawing.Point(408, 48);
			this.btnTim.Name = "btnTim";
			this.btnTim.Size = new System.Drawing.Size(75, 23);
			this.btnTim.TabIndex = 0;
			this.btnTim.Text = "Tìm";
			this.btnTim.UseVisualStyleBackColor = true;
			this.btnTim.Click += new System.EventHandler(this.btnTim_Click);
			// 
			// btnThoat
			// 
			this.btnThoat.Location = new System.Drawing.Point(408, 113);
			this.btnThoat.Name = "btnThoat";
			this.btnThoat.Size = new System.Drawing.Size(75, 23);
			this.btnThoat.TabIndex = 1;
			this.btnThoat.Text = "Thoát";
			this.btnThoat.UseVisualStyleBackColor = true;
			this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(6, -3);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(113, 19);
			this.label1.TabIndex = 2;
			this.label1.Text = "Nhập dữ liệu :";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(78, 47);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(70, 13);
			this.label2.TabIndex = 3;
			this.label2.Text = "Số nguyên a:";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(78, 131);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(70, 13);
			this.label3.TabIndex = 4;
			this.label3.Text = "Số nguyên b:";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(19, 222);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(65, 19);
			this.label4.TabIndex = 5;
			this.label4.Text = "Kết quả";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(115, 47);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(0, 13);
			this.label6.TabIndex = 7;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.Location = new System.Drawing.Point(12, -3);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(81, 19);
			this.label7.TabIndex = 8;
			this.label7.Text = "Tùy chọn:";
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.PaleGreen;
			this.panel1.Controls.Add(this.txtB);
			this.panel1.Controls.Add(this.txtA);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Location = new System.Drawing.Point(12, 12);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(327, 207);
			this.panel1.TabIndex = 9;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
			this.panel2.Controls.Add(this.radBSCNN);
			this.panel2.Controls.Add(this.radUSCLN);
			this.panel2.Controls.Add(this.label7);
			this.panel2.Controls.Add(this.label6);
			this.panel2.Location = new System.Drawing.Point(345, 12);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(182, 207);
			this.panel2.TabIndex = 10;
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.txtKetQua);
			this.panel3.Controls.Add(this.btnTim);
			this.panel3.Controls.Add(this.btnThoat);
			this.panel3.Location = new System.Drawing.Point(12, 225);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(515, 175);
			this.panel3.TabIndex = 11;
			// 
			// txtA
			// 
			this.txtA.Location = new System.Drawing.Point(154, 44);
			this.txtA.Name = "txtA";
			this.txtA.Size = new System.Drawing.Size(162, 20);
			this.txtA.TabIndex = 5;
			// 
			// txtB
			// 
			this.txtB.Location = new System.Drawing.Point(154, 124);
			this.txtB.Name = "txtB";
			this.txtB.Size = new System.Drawing.Size(162, 20);
			this.txtB.TabIndex = 6;
			// 
			// txtKetQua
			// 
			this.txtKetQua.Location = new System.Drawing.Point(154, 77);
			this.txtKetQua.Name = "txtKetQua";
			this.txtKetQua.ReadOnly = true;
			this.txtKetQua.Size = new System.Drawing.Size(162, 20);
			this.txtKetQua.TabIndex = 6;
			// 
			// radUSCLN
			// 
			this.radUSCLN.AutoSize = true;
			this.radUSCLN.Location = new System.Drawing.Point(24, 47);
			this.radUSCLN.Name = "radUSCLN";
			this.radUSCLN.Size = new System.Drawing.Size(61, 17);
			this.radUSCLN.TabIndex = 9;
			this.radUSCLN.TabStop = true;
			this.radUSCLN.Text = "USCLN";
			this.radUSCLN.UseVisualStyleBackColor = true;
			// 
			// radBSCNN
			// 
			this.radBSCNN.AutoSize = true;
			this.radBSCNN.Location = new System.Drawing.Point(24, 129);
			this.radBSCNN.Name = "radBSCNN";
			this.radBSCNN.Size = new System.Drawing.Size(62, 17);
			this.radBSCNN.TabIndex = 10;
			this.radBSCNN.TabStop = true;
			this.radBSCNN.Text = "BSCNN";
			this.radBSCNN.UseVisualStyleBackColor = true;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(539, 412);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Name = "Form1";
			this.Text = "Tìm USCLN và BSCNN của số nguyên a và b";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.panel3.ResumeLayout(false);
			this.panel3.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnTim;
		private System.Windows.Forms.Button btnThoat;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.TextBox txtB;
		private System.Windows.Forms.TextBox txtA;
		private System.Windows.Forms.RadioButton radBSCNN;
		private System.Windows.Forms.RadioButton radUSCLN;
		private System.Windows.Forms.TextBox txtKetQua;
	}
}

