﻿namespace ThucHanh3
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.txtInput = new System.Windows.Forms.TextBox();
			this.btnInput = new System.Windows.Forms.Button();
			this.lsbDaySo = new System.Windows.Forms.ListBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.btnTang2 = new System.Windows.Forms.Button();
			this.btnChanDau = new System.Windows.Forms.Button();
			this.btnLeCuoi = new System.Windows.Forms.Button();
			this.btnXoaChon = new System.Windows.Forms.Button();
			this.btnXoaCuoi = new System.Windows.Forms.Button();
			this.btnXoaDau = new System.Windows.Forms.Button();
			this.btnClose = new System.Windows.Forms.Button();
			this.btnXoaDaySo = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Cyan;
			this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(111, 19);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(360, 31);
			this.label1.TabIndex = 0;
			this.label1.Text = "ỨNG DỤNG SỮ LÝ DÃY SỐ";
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.Cyan;
			this.panel1.Controls.Add(this.label1);
			this.panel1.Location = new System.Drawing.Point(-2, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(579, 78);
			this.panel1.TabIndex = 1;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.btnInput);
			this.panel2.Controls.Add(this.txtInput);
			this.panel2.Controls.Add(this.label2);
			this.panel2.Location = new System.Drawing.Point(-2, 84);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(803, 68);
			this.panel2.TabIndex = 2;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(14, -3);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(133, 19);
			this.label2.TabIndex = 0;
			this.label2.Text = "Nhập số nguyên :";
			// 
			// txtInput
			// 
			this.txtInput.Location = new System.Drawing.Point(117, 25);
			this.txtInput.Name = "txtInput";
			this.txtInput.Size = new System.Drawing.Size(249, 20);
			this.txtInput.TabIndex = 1;
			// 
			// btnInput
			// 
			this.btnInput.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnInput.Location = new System.Drawing.Point(396, 15);
			this.btnInput.Name = "btnInput";
			this.btnInput.Size = new System.Drawing.Size(75, 30);
			this.btnInput.TabIndex = 2;
			this.btnInput.Text = "Nhập số";
			this.btnInput.UseVisualStyleBackColor = true;
			this.btnInput.Click += new System.EventHandler(this.btnInput_Click);
			this.btnInput.Validating += new System.ComponentModel.CancelEventHandler(this.txtInput_KeyDown);
			// 
			// lsbDaySo
			// 
			this.lsbDaySo.FormattingEnabled = true;
			this.lsbDaySo.Location = new System.Drawing.Point(-2, 153);
			this.lsbDaySo.Name = "lsbDaySo";
			this.lsbDaySo.Size = new System.Drawing.Size(241, 355);
			this.lsbDaySo.TabIndex = 3;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.btnXoaDau);
			this.groupBox1.Controls.Add(this.btnXoaCuoi);
			this.groupBox1.Controls.Add(this.btnXoaChon);
			this.groupBox1.Controls.Add(this.btnLeCuoi);
			this.groupBox1.Controls.Add(this.btnChanDau);
			this.groupBox1.Controls.Add(this.btnTang2);
			this.groupBox1.Location = new System.Drawing.Point(245, 153);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(332, 355);
			this.groupBox1.TabIndex = 4;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Chức năng";
			// 
			// btnTang2
			// 
			this.btnTang2.Location = new System.Drawing.Point(75, 42);
			this.btnTang2.Name = "btnTang2";
			this.btnTang2.Size = new System.Drawing.Size(213, 23);
			this.btnTang2.TabIndex = 0;
			this.btnTang2.Text = "Tăng mỗi phần tử lên 2";
			this.btnTang2.UseVisualStyleBackColor = true;
			this.btnTang2.Click += new System.EventHandler(this.btnTang2_Click);
			// 
			// btnChanDau
			// 
			this.btnChanDau.Location = new System.Drawing.Point(75, 91);
			this.btnChanDau.Name = "btnChanDau";
			this.btnChanDau.Size = new System.Drawing.Size(213, 23);
			this.btnChanDau.TabIndex = 1;
			this.btnChanDau.Text = "Chọn số chẵn đầu tiên";
			this.btnChanDau.UseVisualStyleBackColor = true;
			this.btnChanDau.Click += new System.EventHandler(this.btnChanDau_Click);
			// 
			// btnLeCuoi
			// 
			this.btnLeCuoi.Location = new System.Drawing.Point(75, 149);
			this.btnLeCuoi.Name = "btnLeCuoi";
			this.btnLeCuoi.Size = new System.Drawing.Size(213, 23);
			this.btnLeCuoi.TabIndex = 2;
			this.btnLeCuoi.Text = "Chọn số lẻ cuối cùng";
			this.btnLeCuoi.UseVisualStyleBackColor = true;
			this.btnLeCuoi.Click += new System.EventHandler(this.btnLeCuoi_Click);
			// 
			// btnXoaChon
			// 
			this.btnXoaChon.Location = new System.Drawing.Point(75, 200);
			this.btnXoaChon.Name = "btnXoaChon";
			this.btnXoaChon.Size = new System.Drawing.Size(213, 23);
			this.btnXoaChon.TabIndex = 3;
			this.btnXoaChon.Text = "Xóa phần tử đang chọn";
			this.btnXoaChon.UseVisualStyleBackColor = true;
			this.btnXoaChon.Click += new System.EventHandler(this.btnXoaChon_Click);
			// 
			// btnXoaCuoi
			// 
			this.btnXoaCuoi.Location = new System.Drawing.Point(75, 310);
			this.btnXoaCuoi.Name = "btnXoaCuoi";
			this.btnXoaCuoi.Size = new System.Drawing.Size(213, 23);
			this.btnXoaCuoi.TabIndex = 4;
			this.btnXoaCuoi.Text = "Xóa phần tử cuối";
			this.btnXoaCuoi.UseVisualStyleBackColor = true;
			this.btnXoaCuoi.Click += new System.EventHandler(this.btnXoaCuoi_Click);
			// 
			// btnXoaDau
			// 
			this.btnXoaDau.Location = new System.Drawing.Point(75, 256);
			this.btnXoaDau.Name = "btnXoaDau";
			this.btnXoaDau.Size = new System.Drawing.Size(213, 23);
			this.btnXoaDau.TabIndex = 5;
			this.btnXoaDau.Text = "Xóa phần tử đầu";
			this.btnXoaDau.UseVisualStyleBackColor = true;
			this.btnXoaDau.Click += new System.EventHandler(this.btnXoaDau_Click);
			// 
			// btnClose
			// 
			this.btnClose.Location = new System.Drawing.Point(40, 530);
			this.btnClose.Name = "btnClose";
			this.btnClose.Size = new System.Drawing.Size(199, 23);
			this.btnClose.TabIndex = 6;
			this.btnClose.Text = "Kết thúc ứng dụng";
			this.btnClose.UseVisualStyleBackColor = true;
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// btnXoaDaySo
			// 
			this.btnXoaDaySo.Location = new System.Drawing.Point(320, 530);
			this.btnXoaDaySo.Name = "btnXoaDaySo";
			this.btnXoaDaySo.Size = new System.Drawing.Size(213, 23);
			this.btnXoaDaySo.TabIndex = 7;
			this.btnXoaDaySo.Text = "Xóa dãy số";
			this.btnXoaDaySo.UseVisualStyleBackColor = true;
			this.btnXoaDaySo.Click += new System.EventHandler(this.btnXoaDaySo_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(579, 565);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.btnXoaDaySo);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.lsbDaySo);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button btnInput;
		private System.Windows.Forms.TextBox txtInput;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ListBox lsbDaySo;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button btnXoaDau;
		private System.Windows.Forms.Button btnXoaCuoi;
		private System.Windows.Forms.Button btnXoaChon;
		private System.Windows.Forms.Button btnLeCuoi;
		private System.Windows.Forms.Button btnChanDau;
		private System.Windows.Forms.Button btnTang2;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Button btnXoaDaySo;
	}
}

