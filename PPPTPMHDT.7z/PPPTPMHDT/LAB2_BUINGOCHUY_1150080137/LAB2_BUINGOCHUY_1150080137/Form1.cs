﻿using System;
using System.Windows.Forms;

namespace LAB2_BUINGOCHUY_1150080137
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		// Hàm dùng chung để lấy số an toàn
		private bool TryGetNumbers(out double a, out double b)
		{
			a = 0; b = 0;

			if (!double.TryParse(txtA.Text.Trim(), out a))
			{
				MessageBox.Show("Giá trị nhập vào ô a không hợp lệ!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
				txtA.Focus();
				return false;
			}

			if (!double.TryParse(txtB.Text.Trim(), out b))
			{
				MessageBox.Show("Giá trị nhập vào ô b không hợp lệ!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
				txtB.Focus();
				return false;
			}

			return true;
		}

		// Nút Cộng
		private void btnCong_Click(object sender, EventArgs e)
		{
			double a, b;
			if (TryGetNumbers(out a, out b))
			{
				txtKetQua.Text = (a + b).ToString();
			}
		}

		// Nút Trừ
		private void btnTru_Click(object sender, EventArgs e)
		{
			double a, b;
			if (TryGetNumbers(out a, out b))
			{
				txtKetQua.Text = (a - b).ToString();
			}
		}

		// Nút Nhân
		private void btnNhan_Click(object sender, EventArgs e)
		{
			double a, b;
			if (TryGetNumbers(out a, out b))
			{
				txtKetQua.Text = (a * b).ToString();
			}
		}

		// Nút Chia
		private void btnChia_Click(object sender, EventArgs e)
		{
			double a, b;
			if (TryGetNumbers(out a, out b))
			{
				if (b == 0)
				{
					MessageBox.Show("Mẫu số không được phép bằng 0. Vui lòng nhập lại!", "Lỗi chia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					txtB.Clear();
					txtB.Focus();
					return; 
				}
				txtKetQua.Text = (a / b).ToString();
			}
		}

		// Nút Xóa
		private void btnXoa_Click(object sender, EventArgs e)
		{
			txtA.Clear();
			txtB.Clear();
			txtKetQua.Clear();
			txtA.Focus();
		}

		// Nút Thoát
		private void btnThoat_Click(object sender, EventArgs e)
		{
			DialogResult result = MessageBox.Show("Bạn có chắc muốn thoát?",
												  "Xác nhận",
												  MessageBoxButtons.YesNo,
												  MessageBoxIcon.Question);
			if (result == DialogResult.Yes)
			{
				this.Close();
			}
		}
	}
}
