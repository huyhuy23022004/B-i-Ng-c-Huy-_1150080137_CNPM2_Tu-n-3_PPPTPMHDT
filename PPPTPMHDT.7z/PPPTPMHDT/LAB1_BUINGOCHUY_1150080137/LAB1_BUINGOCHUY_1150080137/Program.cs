﻿using System;
using System.Collections.Generic;
using System.IO;

namespace LAB1_BUINGOCHUY_1150080137
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int choice;
			do
			{
				Console.Clear();
				Console.WriteLine("===== MENU CHUONG TRINH THUC HANH =====");
				Console.WriteLine("1. TH1 - Chu vi & diện tích hình chữ nhật");
				Console.WriteLine("2. TH2 - Tìm số lớn hơn trong 2 số nguyên");
				Console.WriteLine("3. TH3 - Tìm số lớn nhất trong 3 số nguyên + Xếp loại điểm");
				Console.WriteLine("4. TH4 - Tìm số ngày trong tháng");
				Console.WriteLine("5. TH5 - Kiểm tra chẵn/lẻ & âm/không âm");
				Console.WriteLine("6. TH6 - Tính chu vi & diện tích HCN (cách 2)");
				Console.WriteLine("7. TH7 - Chu vi & diện tích tam giác");
				Console.WriteLine("8. TH8 - Giải phương trình bậc 2");
				Console.WriteLine("9. TH9 - Tính tổng mảng nhập từ bàn phím");
				Console.WriteLine("10. TH10 - Sắp xếp mảng bằng Selection Sort (từ file)");
				Console.WriteLine("11. TH11 - Chèn số vào mảng đã sắp xếp");
				Console.WriteLine("0. Thoát");
				Console.Write("Chọn bài thực hành: ");
				if (!int.TryParse(Console.ReadLine(), out choice)) choice = -1;

				Console.Clear();
				switch (choice)
				{
					case 1: TH1(); break;
					case 2: TH2(); break;
					case 3: TH3(); break;
					case 4: TH4(); break;
					case 5: TH5(); break;
					case 6: TH6(); break;
					case 7: TH7(); break;
					case 8: TH8(); break;
					case 9: TH9(); break;
					case 10: TH10(); break;
					case 11: TH11(); break;
					case 0: Console.WriteLine("Thoát chương trình!"); break;
					default: Console.WriteLine("Lựa chọn không hợp lệ!"); break;
				}

				if (choice != 0)
				{
					Console.WriteLine("\nNhấn phím bất kỳ để quay lại MENU...");
					Console.ReadKey();
				}

			} while (choice != 0);
		}

		// ================= TH1 =================
		static void TH1()
		{
			Console.Write("Nhập vào chiều dài: ");
			double a = Convert.ToDouble(Console.ReadLine());
			Console.Write("Nhập vào chiều rộng: ");
			double b = Convert.ToDouble(Console.ReadLine());
			double perimeter = (a + b) * 2;
			double area = a * b;
			Console.WriteLine("Chu vi là: " + perimeter);
			Console.WriteLine("Diện tích là: " + area);
		}

		// ================= TH2 =================
		static void TH2()
		{
			Console.Write("Nhap vao so nguyen a: ");
			int a = Convert.ToInt32(Console.ReadLine());
			Console.Write("Nhap vao so nguyen b: ");
			int b = Convert.ToInt32(Console.ReadLine());
			int max = (a > b) ? a : b;
			Console.WriteLine("So lon hon trong 2 so la: " + max);
		}

		// ================= TH3 =================
		static void TH3()
		{
			Console.Write("Nhap vao so nguyen a: ");
			int a = Convert.ToInt32(Console.ReadLine());
			Console.Write("Nhap vao so nguyen b: ");
			int b = Convert.ToInt32(Console.ReadLine());
			Console.Write("Nhap vao so nguyen c: ");
			int c = Convert.ToInt32(Console.ReadLine());
			int max = (a > b && a > c) ? a : (b > c ? b : c);
			Console.WriteLine("So lon nhat trong 3 so la: {0}", max);

			double diem = 8; // bạn có thể thay thành Console.ReadLine() để nhập
			if (diem > 10 || diem < 0) Console.WriteLine("Diem khong hop le!");
			else if (diem >= 9) Console.WriteLine("Xuat sac!");
			else if (diem >= 8) Console.WriteLine("Gioi!");
			else if (diem >= 6.5) Console.WriteLine("Kha!");
			else if (diem >= 5) Console.WriteLine("Trung binh!");
			else if (diem >= 3.5) Console.WriteLine("Yeu!");
			else Console.WriteLine("Kem!");
		}

		// ================= TH4 =================
		static void TH4()
		{
			Console.Write("Nhap vao nam: ");
			int nam = Convert.ToInt32(Console.ReadLine());
			Console.Write("Nhap vao thang: ");
			int thang = Convert.ToInt32(Console.ReadLine());

			switch (thang)
			{
				case 1:
				case 3:
				case 5:
				case 7:
				case 8:
				case 10:
				case 12:
					Console.WriteLine("Thang co 31 ngay!");
					break;
				case 4:
				case 6:
				case 9:
				case 11:
					Console.WriteLine("Thang co 30 ngay!");
					break;
				case 2:
					if ((nam % 400 == 0) || ((nam % 4 == 0) && (nam % 100 != 0)))
						Console.WriteLine("Thang co 29 ngay!");
					else
						Console.WriteLine("Thang co 28 ngay!");
					break;
				default:
					Console.WriteLine("Thang khong hop le!");
					break;
			}
		}

		// ================= TH5 =================
		static void TH5()
		{
			Console.Write("Nhap vao so nguyen n: ");
			int n = Convert.ToInt32(Console.ReadLine());

			if (n % 2 == 0)
				Console.WriteLine("n la so chan");
			else
				Console.WriteLine("n la so le");

			if (n < 0)
				Console.WriteLine("n la so am");
			else
				Console.WriteLine("n la so khong am");
		}

		// ================= TH6 =================
		static void TH6()
		{
			Console.Write("Nhap chieu dai hinh chu nhat: ");
			double dai = Convert.ToDouble(Console.ReadLine());
			Console.Write("Nhap chieu rong hinh chu nhat: ");
			double rong = Convert.ToDouble(Console.ReadLine());

			double chuvi = 2 * (dai + rong);
			double dientich = dai * rong;

			Console.WriteLine("Chu vi = " + chuvi);
			Console.WriteLine("Dien tich = " + dientich);
		}

		// ================= TH7 =================
		static void TH7()
		{
			Console.Write("Nhap canh a: ");
			double a = Convert.ToDouble(Console.ReadLine());
			Console.Write("Nhap canh b: ");
			double b = Convert.ToDouble(Console.ReadLine());
			Console.Write("Nhap canh c: ");
			double c = Convert.ToDouble(Console.ReadLine());

			if (a + b > c && a + c > b && b + c > a)
			{
				double chuvi = a + b + c;
				double p = chuvi / 2;
				double dientich = Math.Sqrt(p * (p - a) * (p - b) * (p - c));

				Console.WriteLine("Chu vi tam giac = " + chuvi);
				Console.WriteLine("Dien tich tam giac = " + dientich);
			}
			else
			{
				Console.WriteLine("Ba canh tren khong lap thanh tam giac!");
			}
		}

		// ================= TH8 =================
		static void TH8()
		{
			Console.Write("Nhap a: ");
			double a = Convert.ToDouble(Console.ReadLine());
			Console.Write("Nhap b: ");
			double b = Convert.ToDouble(Console.ReadLine());
			Console.Write("Nhap c: ");
			double c = Convert.ToDouble(Console.ReadLine());

			if (a == 0)
			{
				if (b == 0)
				{
					if (c == 0)
						Console.WriteLine("Phuong trinh vo so nghiem");
					else
						Console.WriteLine("Phuong trinh vo nghiem");
				}
				else
				{
					double x = -c / b;
					Console.WriteLine("Phuong trinh bac nhat, x = " + x);
				}
			}
			else
			{
				double delta = b * b - 4 * a * c;

				if (delta < 0)
					Console.WriteLine("Phuong trinh vo nghiem");
				else if (delta == 0)
					Console.WriteLine("Phuong trinh co nghiem kep x = " + (-b / (2 * a)));
				else
				{
					double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
					double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
					Console.WriteLine("Phuong trinh co 2 nghiem: x1 = " + x1 + ", x2 = " + x2);
				}
			}
		}

		// ================= TH9 =================
		static void TH9()
		{
			Console.Write("Nhap so luong phan tu n: ");
			int n = Convert.ToInt32(Console.ReadLine());

			int[] arr = new int[n];
			for (int i = 0; i < n; i++)
			{
				Console.Write("Nhap phan tu arr[{0}]: ", i);
				arr[i] = Convert.ToInt32(Console.ReadLine());
			}

			int tong = 0;
			foreach (int x in arr) tong += x;

			Console.WriteLine("Tong cac phan tu trong mang = " + tong);
		}

		// ================= TH10 =================
		static void TH10()
		{
			string filePath = "input_array.txt";
			if (!File.Exists(filePath))
			{
				Console.WriteLine("Khong tim thay file input_array.txt!");
				return;
			}

			string[] data = File.ReadAllText(filePath).Split(new char[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
			int[] arr = Array.ConvertAll(data, int.Parse);

			for (int i = 0; i < arr.Length - 1; i++)
			{
				int minIndex = i;
				for (int j = i + 1; j < arr.Length; j++)
				{
					if (arr[j] < arr[minIndex]) minIndex = j;
				}
				int temp = arr[minIndex];
				arr[minIndex] = arr[i];
				arr[i] = temp;
			}

			Console.WriteLine("Mang sau khi sap xep tang dan:");
			Console.WriteLine(string.Join(" ", arr));

			File.WriteAllText("sorted_array.txt", string.Join(" ", arr));
		}

		// ================= TH11 =================
		static void TH11()
		{
			string filePath = "sorted_array.txt";
			if (!File.Exists(filePath))
			{
				Console.WriteLine("Khong tim thay file sorted_array.txt! Hay chay TH10 truoc.");
				return;
			}

			string[] data = File.ReadAllText(filePath).Split(new char[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
			List<int> arr = new List<int>(Array.ConvertAll(data, int.Parse));

			Console.Write("Nhap so nguyen can chen: ");
			int x = Convert.ToInt32(Console.ReadLine());

			int pos = arr.BinarySearch(x);
			if (pos < 0) pos = ~pos;

			arr.Insert(pos, x);

			Console.WriteLine("Mang sau khi chen:");
			Console.WriteLine(string.Join(" ", arr));

			File.WriteAllText(filePath, string.Join(" ", arr));
		}
	}
}
