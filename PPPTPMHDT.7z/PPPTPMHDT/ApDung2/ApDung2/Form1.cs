﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace ApDung2
{
	public partial class Form1 : Form
	{
		// Danh sách nhóm và password hợp lệ
		private Dictionary<string, List<string>> passwords;

		public Form1()
		{
			InitializeComponent();

			// Khởi tạo danh sách mật khẩu
			passwords = new Dictionary<string, List<string>>()
			{
				{ "Phát triển công nghệ", new List<string> { "1496", "2673" } },
				{ "Nghiên cứu viên", new List<string> { "7462" } },
				{ "Thiết kế mô hình", new List<string> { "8884", "3842", "3383" } }
			};

			// Setup DataGridView
			dgvLog.ReadOnly = true;
			dgvLog.AllowUserToAddRows = false;
			dgvLog.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
		}

		// Xử lý khi nhấn nút số (gán sự kiện cho btn1..btn9)
		private void NumberButton_Click(object sender, EventArgs e)
		{
			Button btn = sender as Button;
			txtPassword.Text += btn.Text;
		}

		// Nút Clear
		private void btnClear_Click(object sender, EventArgs e)
		{
			txtPassword.Clear();
			txtPassword.Focus();
		}

		// Nút Enter
		private void btnEnter_Click(object sender, EventArgs e)
		{
			string input = txtPassword.Text.Trim();
			string groupName = "Không có";
			string result = "Từ chối!";

			// Kiểm tra mật khẩu
			foreach (var pair in passwords)
			{
				if (pair.Value.Contains(input))
				{
					groupName = pair.Key;
					result = "Chấp nhận!";
					break;
				}
			}

			// Thêm vào log (3 cột: Ngày giờ, Nhóm, Kết quả)
			dgvLog.Rows.Add(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), groupName, result);

			// Reset password box
			txtPassword.Clear();
			txtPassword.Focus();
		}

		// Nút Ring
		private void btnRing_Click(object sender, EventArgs e)
		{
			MessageBox.Show("BÁO ĐỘNG! Người lạ đang cố gắng truy cập!",
							"RING!!!",
							MessageBoxButtons.OK,
							MessageBoxIcon.Warning);
		}
	}
}
